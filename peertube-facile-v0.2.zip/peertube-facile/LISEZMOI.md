# PeerTube Facile

Une clé USB qui transforme un PC en serveur PeerTube, sans connaissances techniques.

- **Clé USB** : installe Debian toute seule, sans aucune question.
- **Assistant web** au premier démarrage, depuis un téléphone ou un ordinateur :
  adresse fixe dans la box, ouverture des ports 80/443 **testée depuis Internet**,
  vérification DNS (o2switch détecté), installation de PeerTube avec HTTPS automatique.
- **Tableau de bord** ensuite : état, mises à jour en un clic, identifiants,
  réglages pour le plugin WordPress, DNS dynamique facultatif.

Le PC ne fait tourner que Debian + PeerTube (dans Docker, avec Caddy pour le HTTPS).

---

## 1. Fabriquer l'image de la clé (une seule fois)

L'image est fabriquée à partir de l'image officielle Debian (dernière version stable),
téléchargée et vérifiée automatiquement.

### Depuis ZimaOS (sans terminal)

1. Avec l'explorateur de fichiers ZimaOS, copie le dossier `peertube-facile`
   dans `/DATA/AppData/` (tu dois obtenir `/DATA/AppData/peertube-facile/construire/...`).
2. Importe `construire/zimaos-fabriquer-la-cle.yaml` :
   **+** → **Install a customized app** → **Import** → onglet **Docker Compose**.
3. Installe. Le conteneur travaille 2 à 10 minutes puis s'arrête.
4. L'image `peertube-facile-debian-13.x.iso` apparaît dans `/DATA/Downloads/peertube-facile/`.
   Tu peux ensuite désinstaller cette app.

### Depuis n'importe quel Linux

```bash
sudo apt install xorriso cpio curl
bash construire/construire-iso.sh
```

## 2. Copier l'image sur une clé USB

Avec **balenaEtcher** (Windows, Mac, Linux) : choisir l'image, choisir la clé, « Flash ».
Avec **Rufus** : accepter le mode **« Image DD »** quand il le propose.
La clé (2 Go minimum) est entièrement effacée.

## 3. Installer sur le PC

1. Brancher le PC **en câble Ethernet** à la box, puis brancher la clé.
2. Allumer et choisir la clé dans le menu de démarrage (touche **F12**, **F11**, **F8** ou **Échap**
   selon la marque, juste à l'allumage).
3. Dans le menu PeerTube Facile, choisir **Installer** (PC récent) ou taper `install` (PC ancien).
   ⚠️ **Tout le disque du PC est effacé.** Sans action, le PC démarre normalement au bout de 30 s.
4. Attendre 10 à 30 minutes. Le PC redémarre : **retirer la clé**.
5. L'écran du PC affiche l'adresse de l'assistant et un **code à 6 chiffres**.
   Sur un autre appareil du même réseau, ouvrir par exemple `http://192.168.1.23:8080`
   et suivre les étapes.

## Pré-requis côté internet

- Un **nom de domaine** (par exemple chez o2switch) pour créer `videos.mondomaine.fr`.
- Une **adresse IPv4 publique** à soi. Chez Free, demander l'« IP fixe V4 full-stack »
  (gratuit) si les ports ne s'ouvrent pas. Les box 4G/5G ne conviennent pas.
- Un PC 64 bits, 4 Go de RAM conseillés, disque selon la quantité de vidéos.

## Contenu

| Dossier | Rôle |
|---|---|
| `construire/` | fabrication de l'image (script + app ZimaOS) |
| `cle-usb/` | réponses automatiques à l'installateur Debian, menus de démarrage |
| `systeme/` | assistant web, script d'installation de PeerTube, message d'accueil |

Sur le PC installé : assistant dans `/opt/peertube-facile`, réglages dans
`/etc/peertube-facile`, PeerTube et ses données dans `/srv/peertube`.

## Dépannage

- **Le PC ne démarre pas sur la clé** : désactiver le « Fast Boot » dans le BIOS ;
  Secure Boot peut rester actif (Debian est signé).
- **Pas de réseau pendant l'installation** : vérifier le câble Ethernet (le Wi-Fi n'est pas géré).
- **L'assistant est inaccessible** : sur l'écran du PC, l'adresse affichée doit commencer
  comme celle de ton téléphone (ex. `192.168.1.`).
- **Journal technique** : `/etc/peertube-facile/journal.log` (session `secours`, mot de passe
  visible dans le tableau de bord).

## État du projet

Version 0.1. L'assistant et le script d'installation ont été testés avec un réseau simulé.
La fabrication de l'image et l'installation automatique de Debian n'ont pas encore été
essayées sur une vraie machine : faire un premier essai sur un PC sans données importantes
(ou dans une machine virtuelle VirtualBox / virt-manager).
