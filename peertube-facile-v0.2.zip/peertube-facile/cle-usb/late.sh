#!/bin/sh
# Fin d'installation : copie l'assistant PeerTube Facile dans le système installé.
# Exécuté par l'installateur Debian (busybox), le système installé est dans /target.
# Chaque étape est indépendante : un souci sur l'une n'empêche pas les suivantes.
T=/target
SRC=/peertube-facile/systeme
mkdir -p "$T/var/log/peertube-facile"
LOG="$T/var/log/peertube-facile/installation.log"
RC=0

etape() {
	echo "== $1" >>"$LOG"
	shift
	if ! "$@" >>"$LOG" 2>&1; then
		echo "   ECHEC" >>"$LOG"
		RC=1
	fi
}

mkdir -p "$T/opt/peertube-facile" "$T/etc/peertube-facile"
etape "Copie de l'assistant" cp -r "$SRC/." "$T/opt/peertube-facile/"
chmod 700 "$T/etc/peertube-facile"
chmod 755 "$T/opt/peertube-facile/"*.sh "$T/opt/peertube-facile/assistant.py" 2>>"$LOG"
etape "Services" cp "$T/opt/peertube-facile/services/peertube-facile.service" \
	"$T/opt/peertube-facile/services/peertube-facile-banner.service" "$T/etc/systemd/system/"

# Activation de l'assistant (le plus important : on le fait avant le reste)
for svc in peertube-facile.service peertube-facile-banner.service avahi-daemon.service; do
	etape "Activation de $svc" chroot "$T" systemctl enable "$svc"
done

# Mot de passe aléatoire pour le compte Linux de secours (premier compte créé)
UTIL="$(grep -E '^[^:]*:[^:]*:1000:' "$T/etc/passwd" | cut -d: -f1 | head -n1)"
if [ -n "$UTIL" ]; then
	PW="$(tr -dc 'A-HJ-NP-Za-km-z2-9' </dev/urandom | head -c 16)"
	if echo "$UTIL:$PW" | chroot "$T" chpasswd >>"$LOG" 2>&1; then
		printf '%s\n%s\n' "$UTIL" "$PW" >"$T/etc/peertube-facile/mot-de-passe-linux"
		chmod 600 "$T/etc/peertube-facile/mot-de-passe-linux"
	else
		echo "   ECHEC du changement de mot de passe" >>"$LOG"
	fi
fi

echo "== Terminé (code $RC)" >>"$LOG"
# On ne bloque jamais l'installation : le journal permet de diagnostiquer.
exit 0
